// Netlify Function: /.netlify/functions/news
// Aggregates RSS feeds from config.json and returns normalized JSON.
const Parser = require('rss-parser');
const parser = new Parser({
  headers: { 'User-Agent': 'News-Starter/1.0 (+https://example.com)' }
});
const path = require('path');
const fs = require('fs');

exports.handler = async (event, context) => {
  try {
    const cfgPath = path.join(process.cwd(), 'config.json');
    const raw = fs.readFileSync(cfgPath, 'utf8');
    const { feeds } = JSON.parse(raw);

    const all = (await Promise.all(feeds.map(async f => {
      try {
        const feed = await parser.parseURL(f.url);
        return (feed.items || []).map(it => ({
          source: f.name || (feed.title || '').trim(),
          title: it.title || '',
          link: it.link || '',
          pubDate: it.pubDate || it.isoDate || null,
          isoDate: it.isoDate || null,
          contentSnippet: it.contentSnippet || it.content?.slice?.(0, 220) || ''
        }));
      } catch (e){
        return [];
      }
    }))).flat();

    const items = all
      .filter(i => i.title && i.link)
      .sort((a,b) => new Date(b.isoDate || b.pubDate || 0) - new Date(a.isoDate || a.pubDate || 0));

    return {
      statusCode: 200,
      headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'public, max-age=60' },
      body: JSON.stringify({ items })
    };
  } catch (e){
    return { statusCode: 500, body: JSON.stringify({ error: 'failed_to_fetch', detail: String(e) }) };
  }
};
