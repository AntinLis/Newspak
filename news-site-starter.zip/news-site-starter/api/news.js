// Vercel Serverless Function: /api/news
// Aggregates RSS feeds from config.json and returns normalized JSON.
const Parser = require('rss-parser');
const parser = new Parser({
  headers: { 'User-Agent': 'News-Starter/1.0 (+https://example.com)' }
});
const path = require('path');
const fs = require('fs');

module.exports = async (req, res) => {
  try {
    const cfgPath = path.join(process.cwd(), 'config.json');
    const raw = fs.readFileSync(cfgPath, 'utf8');
    const { feeds } = JSON.parse(raw);

    const all = (await Promise.all(feeds.map(async f => {
      try {
        const feed = await parser.parseURL(f.url);
        return (feed.items || []).map(it => ({
          source: f.name || (feed.title || '').trim(),
          title: it.title || '',
          link: it.link || '',
          pubDate: it.pubDate || it.isoDate || null,
          isoDate: it.isoDate || null,
          contentSnippet: it.contentSnippet || it.content?.slice?.(0, 220) || ''
        }));
      } catch (e){
        return [];
      }
    }))).flat();

    // sort by date desc
    const items = all
      .filter(i => i.title && i.link)
      .sort((a,b) => new Date(b.isoDate || b.pubDate || 0) - new Date(a.isoDate || a.pubDate || 0));

    res.setHeader('Cache-Control', 's-maxage=300, stale-while-revalidate=600');
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.status(200).send(JSON.stringify({ items }));
  } catch (e){
    res.status(500).send({ error: 'failed_to_fetch', detail: String(e) });
  }
};
